/*
 * The compiler.h file has been split into compiler.h and compiler_types.h.
 * However, to compile bionic we only need the compiler.h.
 */
#include <linux/compiler.h>
